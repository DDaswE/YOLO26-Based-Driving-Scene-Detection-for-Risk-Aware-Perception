"""
Tesla FSD-style mesh visualization module.
Clean, flat top-down rendering with light background, perspective road,
lane markings, top-down vehicles, and risk HUD.

This module implements a top-down "mesh" renderer inspired by Tesla's Full
Self-Driving visualization.  It composites a perspective road with animated
rainbow lane markings, overlays detected objects (vehicles, pedestrians,
signs, traffic lights) using pre-loaded PNG assets or procedural drawing,
tracks objects across frames via a simple centroid tracker, and renders a
risk-assessment HUD.  The output is a single BGR frame suitable for
side-by-side display next to the original camera feed.
"""

import cv2
import numpy as np
from collections import deque
import os as _os

# Resolve the assets/ directory that sits alongside this script so that
# asset loading works regardless of the caller's working directory.
_ASSET_DIR = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "assets")


def _load_asset(filename):
    """Load a single RGBA PNG asset from the assets/ directory next to this script.

    Uses IMREAD_UNCHANGED to preserve the alpha channel, which is required
    for transparent compositing via _overlay_rgba.  Returns None (with a
    warning) if the file is missing, so callers can fall back gracefully.
    """
    path = _os.path.join(_ASSET_DIR, filename)
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        print(f"Warning: could not load {path}")
    return img


# ---------------------------------------------------------------------------
# Module-level globals — loaded once at import time
# ---------------------------------------------------------------------------
# _EGO_CAR_IMG: RGBA top-down sprite of the driver's own vehicle, drawn at
#   the bottom-center of every frame to represent "our car".
_EGO_CAR_IMG = _load_asset("ego_car_topdown.png")
# _FRAME_COUNTER: monotonically increasing integer used to drive the rainbow
#   lane-marking animation (hue offset = frame_idx * 3).
_FRAME_COUNTER = 0
# _VEHICLE_BACK_IMG: RGBA rear-view sprite used when a detected vehicle's
#   bounding box has a near-square aspect ratio (1.0–1.5), implying we are
#   looking at the vehicle's back.
_VEHICLE_BACK_IMG = _load_asset("vehicle_back.png")
# _VEHICLE_SIDE_IMG: RGBA side-view sprite used when the bounding box is
#   noticeably wider or taller than square (aspect > 1.5 or < 1.0).
_VEHICLE_SIDE_IMG = _load_asset("vehicle_side.png")

# ---------------------------------------------------------------------------
# Constants — BGR color palette
# ---------------------------------------------------------------------------
# All colors below are in OpenCV's default BGR channel order.
# The palette is intentionally muted and neutral: light grays, warm tans,
# and soft edges.  This creates a clean, warm light-gray background aesthetic
# where colored elements (rainbow lanes, risk HUD) stand out clearly while
# object outlines remain subtle and non-distracting.
_BG_COLOR = (230, 228, 225)          # warm light gray background BGR
_ROAD_COLOR = (195, 192, 188)        # road surface BGR
_YELLOW_LANE = (0, 200, 255)         # yellow edge lines BGR
_WHITE_LANE = (255, 255, 255)        # white dashed center lines
_VEHICLE_COLOR = (210, 210, 210)     # other vehicles
_EGO_COLOR = (60, 60, 60)           # ego car (dark)
_SHADOW_COLOR = (180, 178, 175)      # shadow beneath cars
_TRAIL_COLOR = (140, 135, 130)       # darker trails for light bg
_PERSON_COLOR = (175, 175, 175)      # person circle
_PERSON_SHADOW = (150, 148, 145)
_SIGN_COLOR = (170, 170, 170)
_SIGN_EDGE = (130, 130, 130)
_LIGHT_BODY = (160, 160, 160)
_LIGHT_EDGE = (120, 120, 120)
_MESH_PERSON = (180, 180, 180)
_MESH_PERSON_EDGE = (110, 110, 110)

_NEXT_TRACK_ID = 0


def _new_track_id():
    """Return the next globally unique track ID.

    This is a simple monotonically increasing counter.  Every newly detected
    object that cannot be matched to an existing track gets a fresh ID, which
    persists across frames until the track is lost.
    """
    global _NEXT_TRACK_ID
    _NEXT_TRACK_ID += 1
    return _NEXT_TRACK_ID


# ---------------------------------------------------------------------------
# Rounded Rectangle Helper
# ---------------------------------------------------------------------------

def _overlay_rgba(background, foreground_rgba, x, y, w, h):
    """Alpha-blend an RGBA foreground image onto a BGR background in-place.

    The foreground is first resized to (w, h).  Then the visible region is
    clipped to the background bounds — this handles sprites that are
    partially off-screen (negative x/y or extending past the right/bottom
    edge).  The clipping math maps the visible rectangle in background
    coordinates (x1,y1)-(x2,y2) back to the corresponding sub-rectangle in
    the resized foreground via offsets (fx1,fy1)-(fx2,fy2).

    Compositing uses the standard "over" formula per pixel:
        out = fg * alpha + bg * (1 - alpha)
    where alpha is the foreground's 4th channel normalized to [0, 1].
    """
    if foreground_rgba is None or w < 2 or h < 2:
        return
    bg_h, bg_w = background.shape[:2]

    # Resize foreground to target size
    resized = cv2.resize(foreground_rgba, (w, h), interpolation=cv2.INTER_AREA)

    # Compute visible region (clip to frame bounds)
    x1 = max(0, x)
    y1 = max(0, y)
    x2 = min(bg_w, x + w)
    y2 = min(bg_h, y + h)

    if x1 >= x2 or y1 >= y2:
        return

    # Map the clipped background region back to foreground pixel coordinates.
    # If x was negative, fx1 skips the off-screen left portion of the sprite.
    fx1 = x1 - x
    fy1 = y1 - y
    fx2 = fx1 + (x2 - x1)
    fy2 = fy1 + (y2 - y1)

    fg_crop = resized[fy1:fy2, fx1:fx2]
    alpha = fg_crop[:, :, 3:4].astype(np.float32) / 255.0
    fg_rgb = fg_crop[:, :, :3].astype(np.float32)
    bg_region = background[y1:y2, x1:x2].astype(np.float32)

    blended = fg_rgb * alpha + bg_region * (1.0 - alpha)
    background[y1:y2, x1:x2] = blended.astype(np.uint8)


def _draw_rounded_rect(layer, x1, y1, x2, y2, radius, fill_color,
                       edge_color=None, edge_thick=1):
    """Draw a filled rounded rectangle using a composite-shape approach.

    OpenCV has no native rounded-rect primitive, so we build one from:
      - Two overlapping filled rectangles (one horizontal, one vertical) that
        together cover the interior except the four corners.
      - Four filled circles (one at each corner) that plug the gaps.
    This guarantees a seamless fill with no visible seams.

    If edge_color is provided, the outline is drawn as:
      - Four straight line segments (top, bottom, left, right edges between
        the corner radii).
      - Four 90-degree elliptic arcs (one per corner), each starting at the
        tangent point of the adjacent straight segment.
    """
    r = min(radius, (x2 - x1) // 2, (y2 - y1) // 2)
    r = max(r, 0)
    # Horizontal strip (full width minus corners) + vertical strip (full height minus corners)
    cv2.rectangle(layer, (x1 + r, y1), (x2 - r, y2), fill_color, -1)
    cv2.rectangle(layer, (x1, y1 + r), (x2, y2 - r), fill_color, -1)
    # Four corner circles to round out the corners
    cv2.circle(layer, (x1 + r, y1 + r), r, fill_color, -1, cv2.LINE_AA)
    cv2.circle(layer, (x2 - r, y1 + r), r, fill_color, -1, cv2.LINE_AA)
    cv2.circle(layer, (x1 + r, y2 - r), r, fill_color, -1, cv2.LINE_AA)
    cv2.circle(layer, (x2 - r, y2 - r), r, fill_color, -1, cv2.LINE_AA)
    if edge_color is not None:
        # Straight edge segments between corner arcs
        cv2.line(layer, (x1 + r, y1), (x2 - r, y1), edge_color, edge_thick, cv2.LINE_AA)
        cv2.line(layer, (x1 + r, y2), (x2 - r, y2), edge_color, edge_thick, cv2.LINE_AA)
        cv2.line(layer, (x1, y1 + r), (x1, y2 - r), edge_color, edge_thick, cv2.LINE_AA)
        cv2.line(layer, (x2, y1 + r), (x2, y2 - r), edge_color, edge_thick, cv2.LINE_AA)
        # 90-degree elliptic arcs for each corner
        cv2.ellipse(layer, (x1 + r, y1 + r), (r, r), 180, 0, 90, edge_color, edge_thick, cv2.LINE_AA)
        cv2.ellipse(layer, (x2 - r, y1 + r), (r, r), 270, 0, 90, edge_color, edge_thick, cv2.LINE_AA)
        cv2.ellipse(layer, (x1 + r, y2 - r), (r, r), 90, 0, 90, edge_color, edge_thick, cv2.LINE_AA)
        cv2.ellipse(layer, (x2 - r, y2 - r), (r, r), 0, 0, 90, edge_color, edge_thick, cv2.LINE_AA)


# ---------------------------------------------------------------------------
# Road & Lane Drawing
# ---------------------------------------------------------------------------

def _draw_background_and_rainbow(frame, frame_idx):
    """Draw the perspective road background with animated rainbow lane markings.

    The road is rendered as a 1-point-perspective trapezoid converging at a
    vanishing point (vp_x, vp_y) placed at horizontal center, 1/3 from top.
    The lane widens linearly from near-zero at the vanishing point to
    lane_spread pixels at the bottom edge, simulating depth.

    The lane fill is a static warm pale-blue trapezoid.  On top of it, the
    left/right edge lines and center line are drawn as animated rainbow
    segments.  Each segment's color is determined by converting an HSV pixel
    to BGR, where the hue cycles through the full 0-180 range (OpenCV's HSV
    hue scale) along the lane length, offset by `frame_idx * 3` so the
    rainbow appears to "flow" forward each frame.

    Depth spacing uses a power curve `t**1.3` instead of linear `t`.  This
    compresses segments near the vanishing point (where perspective makes
    things smaller) and stretches them near the camera, giving a more
    realistic depth distribution than uniform spacing.
    """
    h, w = frame.shape[:2]
    s = w / 1920

    # Fill entire frame with warm light-gray background
    frame[:] = _BG_COLOR

    # Vanishing point: horizontally centered, 1/3 from top
    vp_x, vp_y = w // 2, h // 3
    # Half-width of the lane at the bottom edge of the frame
    lane_spread = w // 10

    # Static fill colors for the lane trapezoid (BGR)
    fill_color = (255, 217, 153)   # BGR — bright pale blue
    edge_color = (255, 190, 115)   # BGR — slightly deeper blue for edges
    center_color = (255, 200, 130) # BGR — center line

    # Filled lane trapezoid — narrow at vanishing point, wide at bottom
    lane_pts = np.array([
        [vp_x - int(lane_spread * 0.05), vp_y],
        [vp_x + int(lane_spread * 0.05), vp_y],
        [vp_x + lane_spread, h],
        [vp_x - lane_spread, h],
    ], dtype=np.int32)
    cv2.fillPoly(frame, [lane_pts], fill_color)

    # Rainbow edge lines — each of 60 segments gets a unique hue that shifts
    # by frame_idx*3 per frame, creating a flowing rainbow animation.
    # Saturation is kept low (80) and value high (245) so colours are pastel
    # and legible against the light background.
    num_seg = 60
    for side in [-1.0, 1.0]:           # -1 = left edge, +1 = right edge
        for i in range(num_seg - 1):
            # Power-curve depth: t**1.3 bunches segments near the vanishing
            # point (small t) and spreads them near the camera (large t).
            t0 = (i / (num_seg - 1)) ** 1.3
            t1 = ((i + 1) / (num_seg - 1)) ** 1.3
            y0 = int(vp_y + (h - vp_y) * t0)
            y1 = int(vp_y + (h - vp_y) * t1)
            frac0 = (y0 - vp_y) / max(h - vp_y, 1)
            frac1 = (y1 - vp_y) / max(h - vp_y, 1)
            x0 = int(vp_x + lane_spread * frac0 * side)
            x1 = int(vp_x + lane_spread * frac1 * side)
            # Hue cycles 0-180 along the lane, shifted by frame_idx for animation
            hue = int((i * 180 / num_seg + frame_idx * 3) % 180)
            hsv_px = np.uint8([[[hue, 80, 245]]])
            color = tuple(int(c) for c in cv2.cvtColor(hsv_px, cv2.COLOR_HSV2BGR)[0][0])
            thick = max(2, int(3 * s))
            cv2.line(frame, (x0, y0), (x1, y1), color, thick, cv2.LINE_AA)

    # Rainbow center line — same hue-cycling logic as edge lines
    for i in range(num_seg - 1):
        t0 = (i / (num_seg - 1)) ** 1.3
        t1 = ((i + 1) / (num_seg - 1)) ** 1.3
        y0 = int(vp_y + (h - vp_y) * t0)
        y1 = int(vp_y + (h - vp_y) * t1)
        hue = int((i * 180 / num_seg + frame_idx * 3) % 180)
        hsv_px = np.uint8([[[hue, 80, 245]]])
        color = tuple(int(c) for c in cv2.cvtColor(hsv_px, cv2.COLOR_HSV2BGR)[0][0])
        thick = max(1, int(2 * s))
        cv2.line(frame, (vp_x, y0), (vp_x, y1), color, thick, cv2.LINE_AA)


# ---------------------------------------------------------------------------
# Vehicle Top-Down Drawing
# ---------------------------------------------------------------------------

def _draw_vehicle_filled(layer, box, s_factor):
    """Render a detected vehicle using the appropriate back or side sprite.

    The aspect ratio of the detection bounding box is used as a heuristic to
    decide which view to show:
      - aspect > 1.5 (wide) or < 1.0 (tall): the vehicle is likely seen from
        the side, or the detection is a partial/cropped box at the frame edge.
        Use the side-view sprite.
      - aspect 1.0–1.5 (roughly square): the vehicle is likely seen from
        behind heading away from us.  Use the back-view sprite.

    Scaling strategy: the sprite's native aspect ratio is preserved.  We
    scale to fit whichever of width or height is the *larger* relative
    dimension of the bbox, so the sprite always fills the box without
    distortion (it may be slightly smaller along the other axis).  The
    result is centered on the bbox center.  If no sprite is loaded, we fall
    back to a plain filled rectangle.
    """
    x1, y1, x2, y2 = [int(v) for v in box]
    bw, bh = x2 - x1, y2 - y1
    if bw < 4 or bh < 4:
        return

    # Choose view based on aspect ratio heuristic
    aspect = bw / max(bh, 1)
    if aspect > 1.5 or aspect < 1.0:
        img = _VEHICLE_SIDE_IMG
    else:
        img = _VEHICLE_BACK_IMG

    if img is not None:
        img_h, img_w = img.shape[:2]
        img_aspect = img_w / max(img_h, 1)
        bbox_aspect = bw / max(bh, 1)

        # Fit to the larger relative dimension so the sprite fills the bbox
        if img_aspect > bbox_aspect:
            draw_w = bw
            draw_h = int(bw / img_aspect)
        else:
            draw_h = bh
            draw_w = int(bh * img_aspect)

        # Center the scaled sprite on the bbox center
        cx = (x1 + x2) // 2
        cy = (y1 + y2) // 2
        draw_x = cx - draw_w // 2
        draw_y = cy - draw_h // 2

        _overlay_rgba(layer, img, draw_x, draw_y, draw_w, draw_h)
    else:
        # Fallback: draw a simple rectangle when asset is missing
        cv2.rectangle(layer, (x1, y1), (x2, y2), (200, 200, 200), -1)


def _draw_person_filled(layer, box, s_factor):
    """Draw a stylized person icon built from proportional body-part shapes.

    All body parts are positioned using bbox-relative fractions so the figure
    scales naturally with the detection size:
      - Head: circle at ~9% from top, radius = 9% of bbox height
      - Torso: trapezoid from neck to 58% of bbox height; shoulders are 32%
        of bbox width, hips are 22% — creating the characteristic tapered shape
      - Arms: small quadrilateral "wings" extending outward from the shoulders
      - Legs: two quadrilaterals from hip line to the bbox bottom

    Each part is filled with _MESH_PERSON and outlined with _MESH_PERSON_EDGE
    for visual definition.
    """
    x1, y1, x2, y2 = [int(v) for v in box]
    cx = (x1 + x2) // 2
    bw, bh = x2 - x1, y2 - y1
    if bw < 3 or bh < 3:
        return
    edge_t = max(1, int(1 * s_factor))

    # Head — circle centered at 9% below the top of the bbox
    head_r = max(int(bh * 0.09), 4)
    head_cy = y1 + int(bh * 0.09) + head_r
    cv2.circle(layer, (cx, head_cy), head_r, _MESH_PERSON, -1, cv2.LINE_AA)
    cv2.circle(layer, (cx, head_cy), head_r, _MESH_PERSON_EDGE, edge_t, cv2.LINE_AA)

    # Torso (trapezoid)
    neck_y = head_cy + head_r
    torso_bottom = y1 + int(bh * 0.58)
    shoulder_half = int(bw * 0.32)
    hip_half = int(bw * 0.22)
    torso_pts = np.array([
        [cx - shoulder_half, neck_y + int(bh * 0.02)],
        [cx + shoulder_half, neck_y + int(bh * 0.02)],
        [cx + hip_half, torso_bottom],
        [cx - hip_half, torso_bottom],
    ], dtype=np.int32)
    cv2.fillPoly(layer, [torso_pts], _MESH_PERSON)
    cv2.polylines(layer, [torso_pts], True, _MESH_PERSON_EDGE, edge_t, cv2.LINE_AA)

    # Left arm
    arm_top_y = neck_y + int(bh * 0.04)
    arm_pts_l = np.array([
        [cx - shoulder_half, arm_top_y],
        [cx - shoulder_half - int(bw * 0.15), arm_top_y + int(bh * 0.22)],
        [cx - shoulder_half - int(bw * 0.08), arm_top_y + int(bh * 0.25)],
        [cx - shoulder_half + int(bw * 0.05), arm_top_y + int(bh * 0.05)],
    ], dtype=np.int32)
    cv2.fillPoly(layer, [arm_pts_l], _MESH_PERSON)

    # Right arm
    arm_pts_r = np.array([
        [cx + shoulder_half, arm_top_y],
        [cx + shoulder_half + int(bw * 0.15), arm_top_y + int(bh * 0.22)],
        [cx + shoulder_half + int(bw * 0.08), arm_top_y + int(bh * 0.25)],
        [cx + shoulder_half - int(bw * 0.05), arm_top_y + int(bh * 0.05)],
    ], dtype=np.int32)
    cv2.fillPoly(layer, [arm_pts_r], _MESH_PERSON)

    # Left leg
    leg_pts_l = np.array([
        [cx - hip_half, torso_bottom],
        [cx - int(bw * 0.05), torso_bottom],
        [cx - int(bw * 0.1), y2],
        [cx - int(bw * 0.3), y2],
    ], dtype=np.int32)
    cv2.fillPoly(layer, [leg_pts_l], _MESH_PERSON)
    cv2.polylines(layer, [leg_pts_l], True, _MESH_PERSON_EDGE, edge_t, cv2.LINE_AA)

    # Right leg
    leg_pts_r = np.array([
        [cx + int(bw * 0.05), torso_bottom],
        [cx + hip_half, torso_bottom],
        [cx + int(bw * 0.3), y2],
        [cx + int(bw * 0.1), y2],
    ], dtype=np.int32)
    cv2.fillPoly(layer, [leg_pts_r], _MESH_PERSON)
    cv2.polylines(layer, [leg_pts_r], True, _MESH_PERSON_EDGE, edge_t, cv2.LINE_AA)


def _draw_sign_filled(layer, box, s_factor):
    """Draw a traffic sign as a simple square-on-a-pole icon.

    The sign face is a filled square (sized to the smaller of bbox width and
    60% of height) with an outlined edge, and a thin vertical pole extends
    from the bottom of the sign face to the bottom of the bbox.
    """
    x1, y1, x2, y2 = [int(v) for v in box]
    bw, bh = x2 - x1, y2 - y1
    if bw < 3 or bh < 3:
        return
    # Small square sign
    sign_size = min(bw, int(bh * 0.6))
    sx1 = (x1 + x2) // 2 - sign_size // 2
    sy1 = y1
    sx2 = sx1 + sign_size
    sy2 = sy1 + sign_size
    cv2.rectangle(layer, (sx1, sy1), (sx2, sy2), _SIGN_COLOR, -1)
    cv2.rectangle(layer, (sx1, sy1), (sx2, sy2), _SIGN_EDGE,
                  max(1, int(2 * s_factor)), cv2.LINE_AA)
    # Pole
    cx = (x1 + x2) // 2
    pole_half = max(int(bw * 0.06), 1)
    cv2.rectangle(layer, (cx - pole_half, sy2), (cx + pole_half, y2),
                  _SIGN_EDGE, -1)


def _draw_traffic_light_filled(layer, box, s_factor):
    """Draw a traffic light as an outlined rectangle with three colored circles.

    The body fills the full bounding box.  Three circles (red, yellow, green
    — in BGR) are placed at 20%, 50%, and 80% of the bbox height to mimic
    a standard vertical traffic light.  Circle radius scales with the
    narrower bbox dimension.
    """
    x1, y1, x2, y2 = [int(v) for v in box]
    bw, bh = x2 - x1, y2 - y1
    if bw < 3 or bh < 3:
        return
    cv2.rectangle(layer, (x1, y1), (x2, y2), _LIGHT_BODY, -1)
    cv2.rectangle(layer, (x1, y1), (x2, y2), _LIGHT_EDGE,
                  max(1, int(2 * s_factor)), cv2.LINE_AA)
    cx = (x1 + x2) // 2
    r = max(int(min(bw, bh / 3) * 0.28), 3)
    light_colors = [(80, 80, 200), (80, 180, 200), (80, 180, 80)]
    for i, frac in enumerate([0.20, 0.50, 0.80]):
        cy = y1 + int(bh * frac)
        cv2.circle(layer, (cx, cy), r, light_colors[i], -1, cv2.LINE_AA)


# ---------------------------------------------------------------------------
# Class-name-to-renderer dispatch
# ---------------------------------------------------------------------------
# _MESH_FUNCS maps lowercase detection class names to the appropriate drawing
# function.  Multiple synonyms (e.g. "car", "truck", "bus", "vehicle") can
# map to the same renderer.  This keeps the caller simple — just look up
# the class name and call the returned function.
_MESH_FUNCS = {
    "car": _draw_vehicle_filled,
    "truck": _draw_vehicle_filled,
    "bus": _draw_vehicle_filled,
    "vehicle": _draw_vehicle_filled,
    "person": _draw_person_filled,
    "pedestrian": _draw_person_filled,
    "traffic sign": _draw_sign_filled,
    "sign": _draw_sign_filled,
    "traffic light": _draw_traffic_light_filled,
}

# Fallback renderer for any class not explicitly listed above.
# Vehicles are the most common object, so using the vehicle renderer as
# the default produces reasonable results for unknown classes.
_DEFAULT_MESH = _draw_vehicle_filled


def _get_mesh_func(class_name):
    """Look up the mesh drawing function for a given class name.

    Normalizes to lowercase and strips whitespace, then falls back to
    _DEFAULT_MESH (vehicle renderer) if the class is not in the dispatch dict.
    """
    key = class_name.lower().strip()
    return _MESH_FUNCS.get(key, _DEFAULT_MESH)


# ---------------------------------------------------------------------------
# Clip Detections
# ---------------------------------------------------------------------------

def _clip_detections(detections, ego_boundary_y):
    """Clip detection boxes so they don't extend below the ego boundary.

    The bottom strip of the frame is reserved for the ego car sprite.  Any
    detection whose top edge (y1) is entirely within the ego zone is dropped.
    Detections that straddle the boundary have their bottom edge (y2) clamped
    to ego_boundary_y, preventing drawn objects from visually overlapping the
    ego car.  Boxes that become too small after clipping (< 4px tall) are
    also discarded.
    """
    clipped = []
    for det in detections:
        x1, y1, x2, y2 = det["box"]
        if y1 >= ego_boundary_y:
            continue
        y2_clipped = min(y2, float(ego_boundary_y))
        if y2_clipped - y1 < 4:
            continue
        clipped_det = dict(det)
        clipped_det["box"] = [x1, y1, x2, y2_clipped]
        clipped.append(clipped_det)
    return clipped


# ---------------------------------------------------------------------------
# Ego Car
# ---------------------------------------------------------------------------

def _draw_ego_car(frame, ego_boundary_y=None):
    """Draw the driver's own vehicle at bottom center using the ego car sprite.

    The ego car is intentionally drawn at 1.5x the ego-row height (the
    `* 1.5` factor) so it appears prominent and clearly represents "our"
    vehicle in the scene.  The sprite is centered horizontally on the frame
    and vertically within the ego row.  Aspect ratio is preserved from the
    source PNG.

    If the ego car sprite failed to load at import time, a simple dark
    filled rectangle is drawn as a fallback so the ego zone is never empty.
    """
    h, w = frame.shape[:2]
    s = w / 1920

    ego_top = ego_boundary_y if ego_boundary_y is not None else h - h // 7
    ego_row_h = h - ego_top

    # 1.5x upscale factor makes the ego car visually dominant
    car_h = int(ego_row_h * 0.85 * 1.5)
    if _EGO_CAR_IMG is not None:
        # Derive width from height to preserve the original aspect ratio
        orig_h, orig_w = _EGO_CAR_IMG.shape[:2]
        car_w = int(car_h * orig_w / orig_h)
    else:
        car_w = int(car_h * 1.25)

    # Center the sprite horizontally and vertically within the ego row
    cx = w // 2
    car_x = cx - car_w // 2
    car_y = ego_top + (ego_row_h - car_h) // 2

    if _EGO_CAR_IMG is not None:
        # RGBA overlay preserves the sprite's transparency
        _overlay_rgba(frame, _EGO_CAR_IMG, car_x, car_y, car_w, car_h)
    else:
        # Fallback dark rectangle when the PNG asset is missing
        cv2.rectangle(frame, (car_x, car_y), (car_x + car_w, car_y + car_h), (60, 60, 60), -1)


# ---------------------------------------------------------------------------
# Simple Centroid Tracker
# ---------------------------------------------------------------------------

def update_tracks(prev_tracks, detections, max_distance=200):
    """Centroid-based nearest-neighbor object tracker with class matching.

    For each detection in the current frame, we compute its centroid and
    search prev_tracks for the closest previous track of the *same class*
    within max_distance pixels.  This prevents a car from "stealing" a
    pedestrian's track ID.  Matched tracks keep their ID and append the new
    centroid to a deque(maxlen=10) — this bounded history is used later by
    _draw_motion_trails to render fading tail lines.

    Unmatched detections are assigned a fresh monotonic ID via _new_track_id
    and start a new position history.  Tracks from the previous frame that
    receive no match are implicitly dropped (not carried forward).

    Returns updated_tracks dict:
        {track_id: {"class": str, "positions": deque(maxlen=10)}}
    """
    new_tracks = {}
    used_prev = set()

    for det in detections:
        cx = (det["box"][0] + det["box"][2]) / 2
        cy = (det["box"][1] + det["box"][3]) / 2
        cls = det["class_name"]

        best_id = None
        best_dist = max_distance

        for tid, trk in prev_tracks.items():
            if tid in used_prev:
                continue
            if trk["class"] != cls:
                continue
            prev_pos = trk["positions"][-1]
            d = ((cx - prev_pos[0]) ** 2 + (cy - prev_pos[1]) ** 2) ** 0.5
            if d < best_dist:
                best_dist = d
                best_id = tid

        if best_id is not None:
            used_prev.add(best_id)
            positions = prev_tracks[best_id]["positions"]
            positions.append((cx, cy))
            new_tracks[best_id] = {"class": cls, "positions": positions}
        else:
            tid = _new_track_id()
            positions = deque(maxlen=10)
            positions.append((cx, cy))
            new_tracks[tid] = {"class": cls, "positions": positions}

    return new_tracks


# ---------------------------------------------------------------------------
# Motion Trails (dark for light background)
# ---------------------------------------------------------------------------

def _draw_motion_trails(mesh, tracks, s_factor, ego_boundary_y=None):
    """Draw fading motion trails behind each tracked object.

    For every track with at least 2 position samples, we draw line segments
    connecting consecutive centroids.  Each segment's visual weight increases
    from old to new:
      - `frac` goes from near-0 (oldest segment) to 1.0 (most recent).
      - Thickness grows linearly with frac (thin tail → thick head).
      - Alpha (color intensity) ramps from 0.3 to 1.0, achieved by scaling
        the _TRAIL_COLOR channels by the alpha factor.  This creates the
        visual effect of the trail "fading out" into the background.

    Y-coordinates are clamped to ego_boundary_y to keep trails from bleeding
    into the ego car zone at the bottom of the frame.
    """
    max_y = ego_boundary_y if ego_boundary_y is not None else mesh.shape[0]
    for trk in tracks.values():
        pts = list(trk["positions"])
        if len(pts) < 2:
            continue
        n = len(pts)
        for i in range(n - 1):
            p1 = (int(pts[i][0]), min(int(pts[i][1]), max_y))
            p2 = (int(pts[i + 1][0]), min(int(pts[i + 1][1]), max_y))
            # frac increases from oldest (0) to newest (1) segment
            frac = (i + 1) / n
            thick = max(int(1 + 3 * frac * s_factor), 1)
            # Simulate alpha blending by dimming the trail color
            alpha = 0.3 + 0.7 * frac
            seg_color = tuple(int(c * alpha) for c in _TRAIL_COLOR)
            cv2.line(mesh, p1, p2, seg_color, thick, cv2.LINE_AA)


# ---------------------------------------------------------------------------
# Risk HUD (top-right, adapted for light background)
# ---------------------------------------------------------------------------

def _draw_risk_hud(mesh, risk_level, risk_history, risk_colors):
    """Render the risk-assessment heads-up display in the top-right corner.

    The HUD has three visual components:

    1. **Semicircle gauge** — five arc segments spanning 180-360 degrees
       (i.e. the bottom half of a circle).  The segments transition from
       green (low risk, left) through yellow (medium) to red (high risk,
       right).  A needle rotates from 180 degrees (risk=0, pointing left)
       to 360 degrees (risk=5, pointing right), driven by the latest EMA
       (exponential moving average) risk value.

    2. **Risk label** — the text "LOW" / "MEDIUM" / "HIGH" rendered above
       the gauge in the corresponding risk_colors color.

    3. **Mini rolling EMA plot** — a small line chart below the gauge
       showing the recent history of the EMA risk score (0–5 scale).  This
       lets the viewer see trends (rising/falling risk) at a glance.
    """
    h, w = mesh.shape[:2]
    s = w / 1920

    hud_right = w - int(40 * s)
    hud_top = int(40 * s)

    gauge_r = int(100 * s)
    gauge_cx = hud_right - int(140 * s)
    gauge_cy = hud_top + int(160 * s)

    # Risk level text — colored word centered above the gauge
    color = risk_colors.get(risk_level, (80, 80, 80))
    text_size = 1.8 * s
    text_thick = max(1, int(3 * s))
    (tw, th), _ = cv2.getTextSize(risk_level, cv2.FONT_HERSHEY_SIMPLEX,
                                  text_size, text_thick)
    text_x = gauge_cx - tw // 2
    text_y = hud_top + int(30 * s)
    cv2.putText(mesh, risk_level, (text_x, text_y),
                cv2.FONT_HERSHEY_SIMPLEX, text_size, color,
                text_thick, cv2.LINE_AA)

    # Semicircle gauge — five colored arc segments from 180 to 360 degrees.
    # 180 deg = leftmost (safe), 360 deg = rightmost (dangerous).
    # Colors: green → green → yellow → orange-red → red (BGR order).
    segments = [
        (180, 220, (0, 200, 0)),
        (220, 260, (0, 200, 0)),
        (260, 300, (0, 180, 200)),
        (300, 340, (0, 80, 220)),
        (340, 360, (0, 0, 220)),
    ]
    for start_a, end_a, seg_color in segments:
        cv2.ellipse(mesh, (gauge_cx, gauge_cy), (gauge_r, gauge_r),
                    0, start_a, end_a, seg_color,
                    max(1, int(4 * s)), cv2.LINE_AA)

    # Needle — maps the EMA risk value (0–5) to an angle (180–360 degrees).
    # 0 risk → 180 deg (pointing left = safe), 5 risk → 360 deg (pointing right = danger).
    ema_val = 0.0
    if risk_history and "ema" in risk_history and len(risk_history["ema"]) > 0:
        ema_val = risk_history["ema"][-1]
    ema_val = max(0.0, min(5.0, ema_val))
    needle_angle_deg = 180 + (ema_val / 5.0) * 180
    needle_angle_rad = np.radians(needle_angle_deg)
    needle_len = gauge_r - int(10 * s)
    nx = int(gauge_cx + needle_len * np.cos(needle_angle_rad))
    ny = int(gauge_cy + needle_len * np.sin(needle_angle_rad))
    cv2.line(mesh, (gauge_cx, gauge_cy), (nx, ny),
             (60, 60, 60), max(1, int(2 * s)), cv2.LINE_AA)
    cv2.circle(mesh, (gauge_cx, gauge_cy), max(3, int(5 * s)),
               (60, 60, 60), -1, cv2.LINE_AA)

    # Gauge labels (dark text for light bg)
    label_font = 0.5 * s
    label_color = (100, 100, 100)
    cv2.putText(mesh, "0",
                (gauge_cx - gauge_r - int(15 * s), gauge_cy + int(25 * s)),
                cv2.FONT_HERSHEY_SIMPLEX, label_font, label_color,
                max(1, int(s)), cv2.LINE_AA)
    cv2.putText(mesh, "5",
                (gauge_cx + gauge_r + int(5 * s), gauge_cy + int(25 * s)),
                cv2.FONT_HERSHEY_SIMPLEX, label_font, label_color,
                max(1, int(s)), cv2.LINE_AA)

    # Mini rolling plot — shows the EMA risk history as a line chart so the
    # viewer can see whether risk is trending up or down over recent frames.
    if risk_history and "ema" in risk_history and len(risk_history["ema"]) > 1:
        plot_w = int(260 * s)
        plot_h = int(80 * s)
        plot_x = gauge_cx - plot_w // 2
        plot_y = gauge_cy + int(40 * s)
        cv2.rectangle(mesh, (plot_x, plot_y),
                      (plot_x + plot_w, plot_y + plot_h),
                      (160, 158, 155), max(1, int(s)), cv2.LINE_AA)
        ema_list = list(risk_history["ema"])
        n = len(ema_list)
        max_val = 5.0
        for i in range(1, n):
            x0 = plot_x + int((i - 1) / max(n - 1, 1) * plot_w)
            x1_pt = plot_x + int(i / max(n - 1, 1) * plot_w)
            y0 = plot_y + plot_h - int(
                min(ema_list[i - 1], max_val) / max_val * plot_h)
            y1_pt = plot_y + plot_h - int(
                min(ema_list[i], max_val) / max_val * plot_h)
            cv2.line(mesh, (x0, y0), (x1_pt, y1_pt), color,
                     max(1, int(2 * s)), cv2.LINE_AA)


# ---------------------------------------------------------------------------
# Main Entry Point
# ---------------------------------------------------------------------------

def draw_mesh_frame(frame_shape, detections, risk_level, risk_history,
                    prev_tracks, class_colors, risk_colors):
    """
    Render a full Tesla FSD-style mesh visualization frame.

    Args:
        frame_shape: (height, width, channels) tuple
        detections: list of dicts with keys: class_id, class_name, confidence,
                    box=[x1,y1,x2,y2], partial_risk
        risk_level: "LOW", "MEDIUM", or "HIGH"
        risk_history: dict with "direct", "indirect", "ema" deques
        prev_tracks: dict from previous frame for tracking (or empty dict)
        class_colors: dict mapping class_name -> BGR color tuple (API compat)
        risk_colors: dict mapping risk level -> BGR color tuple

    Returns:
        (mesh_frame, updated_tracks)
    """
    mesh = np.zeros(frame_shape, dtype=np.uint8)
    h, w = frame_shape[:2]
    s = w / 1920

    # The bottom 1/7th of the frame is the "ego zone" — reserved for the
    # ego car sprite.  Detected objects that fall entirely within this zone
    # are skipped, and those that straddle it are clipped.
    ego_boundary_y = h - h // 7

    # --------------- Rendering pipeline ---------------
    # The draw order matters: later layers occlude earlier ones.
    #   1. Background + road + rainbow lanes  (lowest layer)
    #   2. Tracker update  (no drawing, just bookkeeping)
    #   3. Detected objects  (vehicles, people, signs, lights)
    #   4. Ego car  (drawn AFTER objects so it always appears on top — this
    #      ensures nearby objects never visually cover our own car)
    #   5. Risk HUD  (topmost overlay)

    # 1. Background with animated rainbow lanes
    global _FRAME_COUNTER
    _draw_background_and_rainbow(mesh, _FRAME_COUNTER)
    _FRAME_COUNTER += 1

    # 2. Update centroid tracker (produces track IDs + position histories)
    updated_tracks = update_tracks(prev_tracks, detections)

    # 3. Draw detected objects — skip any whose top edge is in the ego zone
    for det in detections:
        x1, y1, x2, y2 = det["box"]
        if y1 >= ego_boundary_y:
            continue
        func = _get_mesh_func(det["class_name"])
        func(mesh, det["box"], s)

    # 4. Ego car drawn AFTER objects so it always renders on top
    _draw_ego_car(mesh, ego_boundary_y)

    # 5. Risk HUD (top-right corner, highest z-order)
    _draw_risk_hud(mesh, risk_level, risk_history, risk_colors)

    return mesh, updated_tracks
