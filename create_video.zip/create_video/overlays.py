# =============================================================================
# overlays.py — HUD Overlay Renderer
#
# Draws heads-up display (HUD) overlays on annotated video frames:
#   1. A horizontal bar chart showing per-class detection counts
#   2. A rolling time-series plot showing real-time risk metrics
#
# Both overlays are rendered in the top-right corner of the frame using
# OpenCV drawing primitives and numpy for alpha blending.
# =============================================================================

"""
Chart overlay module for YOLO visualization.
Draws bar chart and rolling risk plot using OpenCV + numpy.
"""

import cv2
import numpy as np


# =============================================================================
# Utility: Dashed Line Drawing
# =============================================================================

def draw_dashed_line(frame, pt1, pt2, color, thickness=1, dash_length=15, gap_length=10):
    """Draw a dashed line between two points."""
    x1, y1 = pt1
    x2, y2 = pt2
    dx = x2 - x1
    dy = y2 - y1

    # Compute the total Euclidean distance between the two endpoints.
    length = int(np.hypot(dx, dy))
    if length == 0:
        return

    # Normalize the direction vector (dx, dy) to unit length so we can
    # "walk" along the line in pixel-sized steps regardless of angle.
    dx_norm = dx / length
    dy_norm = dy / length

    # Walk along the line parametrically: draw a solid segment of
    # `dash_length` pixels, then skip `gap_length` pixels (the gap).
    # Each iteration advances `pos` by (dash_length + gap_length),
    # producing the alternating dash/gap pattern.
    pos = 0
    while pos < length:
        seg_end = min(pos + dash_length, length)
        start = (int(x1 + dx_norm * pos), int(y1 + dy_norm * pos))
        end = (int(x1 + dx_norm * seg_end), int(y1 + dy_norm * seg_end))
        cv2.line(frame, start, end, color, thickness)
        pos = seg_end + gap_length


# =============================================================================
# Bar Chart: Per-Class Detection Counts
# =============================================================================

def draw_bar_chart(frame, class_counts, class_colors):
    """
    Draw a horizontal bar chart in the top-right corner of the frame.

    Args:
        frame: BGR video frame (3838x2058)
        class_counts: dict mapping class name -> count
        class_colors: dict mapping class name -> BGR tuple

    Returns:
        int: bottom Y coordinate of the bar chart region
    """
    h, w = frame.shape[:2]

    # --- Scaling system ---
    # All pixel dimensions are expressed as proportions of a 3838x2058
    # reference resolution. This ensures the chart looks visually identical
    # regardless of the actual frame size: each constant is multiplied by
    # (w / 3838) or (h / 2058) to scale linearly with resolution.
    chart_w = w // 3  # ~1/3 width
    margin = int(20 * w / 3838)
    bar_height = int(48 * h / 2058)
    bar_gap = int(18 * h / 2058)
    label_w = int(290 * w / 3838)
    count_w = int(100 * w / 3838)
    padding_top = int(24 * h / 2058)
    padding_bottom = int(18 * h / 2058)
    title_height = int(52 * h / 2058)

    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 1.2 * w / 3838
    font_thickness = max(1, int(2.5 * w / 3838))
    title_scale = 1.4 * w / 3838
    title_thickness = max(1, int(3 * w / 3838))

    # Fixed class ordering guarantees that bars always appear in the same
    # vertical position across frames, preventing visual jitter even when
    # some classes have zero detections in a given frame.
    class_order = ["vehicle", "person", "traffic light", "traffic sign"]
    num_bars = len(class_order)

    total_h = padding_top + title_height + num_bars * bar_height + (num_bars - 1) * bar_gap + padding_bottom

    # Region position: top-right
    x1 = w - chart_w - margin
    y1 = margin
    x2 = w - margin
    y2 = y1 + total_h

    # Clamp to frame bounds
    x1 = max(0, x1)
    y1 = max(0, y1)
    x2 = min(w, x2)
    y2 = min(h, y2)

    # --- Semi-transparent background ---
    # We blend the existing frame region with a black rectangle at 60% opacity.
    # Technique: copy the ROI, create an all-black image of the same size,
    # then use addWeighted(original * 0.4 + black * 0.6) to darken the area.
    # This lets the video show through faintly while keeping text readable.
    overlay = frame[y1:y2, x1:x2].copy()
    bg = np.zeros_like(overlay)
    frame[y1:y2, x1:x2] = cv2.addWeighted(overlay, 0.4, bg, 0.6, 0)

    # Title
    title_y = y1 + padding_top + int(title_height * 0.7)
    cv2.putText(frame, "Detections", (x1 + int(10 * w / 3838), title_y),
                font, title_scale, (255, 255, 255), title_thickness, cv2.LINE_AA)

    # --- Bar length scaling ---
    # All bars are scaled proportionally to the maximum count across all
    # displayed classes. This means the longest bar always fills the
    # available width, and shorter bars are proportionally shorter.
    # Minimum of 1 prevents division-by-zero when all counts are 0.
    max_count = max(max((class_counts.get(c, 0) for c in class_order), default=1), 1)

    # --- Layout math ---
    # Each row is divided into three zones left-to-right:
    #   1. label_w: space for the class name text (e.g. "vehicle")
    #   2. available_bar_w: the horizontal bar itself, scaled to count
    #   3. count_w: numeric count displayed after the bar
    # A small padding (30px at reference res) separates these zones.
    available_bar_w = chart_w - label_w - count_w - int(30 * w / 3838)

    # Draw bars
    for i, cls in enumerate(class_order):
        count = class_counts.get(cls, 0)
        color = class_colors.get(cls, (200, 200, 200))

        bar_y = y1 + padding_top + title_height + i * (bar_height + bar_gap)

        # Label text
        label_x = x1 + int(10 * w / 3838)
        text_y = bar_y + int(bar_height * 0.75)
        cv2.putText(frame, cls, (label_x, text_y),
                    font, font_scale, (220, 220, 220), font_thickness, cv2.LINE_AA)

        # Bar: length is proportional to (count / max_count)
        bar_x_start = x1 + label_w
        bar_length = int(available_bar_w * count / max_count) if count > 0 else 0
        if bar_length > 0:
            cv2.rectangle(frame,
                          (bar_x_start, bar_y + int(bar_height * 0.15)),
                          (bar_x_start + bar_length, bar_y + int(bar_height * 0.85)),
                          color, -1)

        # Count text at end of bar
        count_x = bar_x_start + bar_length + int(8 * w / 3838)
        cv2.putText(frame, str(count), (count_x, text_y),
                    font, font_scale, color, font_thickness, cv2.LINE_AA)

    return y2


# =============================================================================
# Rolling Plot: Real-Time Risk Time Series
# =============================================================================

def draw_rolling_plot(frame, risk_history, risk_level, risk_colors, bar_chart_bottom=None):
    """
    Draw a rolling risk plot below the bar chart in the top-right.

    Args:
        frame: BGR video frame
        risk_history: dict with keys "direct", "indirect", "ema" — each a deque of floats
        risk_level: str, current risk level ("LOW", "MEDIUM", "HIGH")
        risk_colors: dict mapping level -> BGR color
        bar_chart_bottom: int, Y coord where bar chart ends (or None)
    """
    h, w = frame.shape[:2]

    # --- Positioning: anchored below bar chart ---
    # The plot occupies the same horizontal band as the bar chart (right
    # third of the frame). Vertically, it starts just below bar_chart_bottom
    # with a small gap (plot_gap) so the two overlays don't touch.
    chart_w = w // 3
    margin = int(20 * w / 3838)
    x1 = w - chart_w - margin
    x2 = w - margin
    y1 = bar_chart_bottom if bar_chart_bottom is not None else margin
    plot_gap = int(8 * h / 2058)
    y1 += plot_gap

    # --- Height calculation ---
    # The plot should be at least as tall as the bar chart so the two
    # overlays look balanced, but with a minimum floor of 350px (at
    # reference res). The height is then capped so it doesn't extend
    # past the bottom of the frame.
    bar_chart_h = bar_chart_bottom - margin if bar_chart_bottom else int(200 * h / 2058)
    plot_target_h = max(bar_chart_h, int(350 * h / 2058))  # at least as tall as bar chart
    y2 = y1 + plot_target_h
    y2 = min(y2, h - margin)  # don't go past frame bottom

    # Clamp
    x1 = max(0, x1)
    y1 = max(0, y1)
    x2 = min(w, x2)
    y2 = min(h, y2)

    plot_h = y2 - y1
    plot_w = x2 - x1
    if plot_h < 20 or plot_w < 20:
        return

    # --- Semi-transparent background ---
    # Same technique as the bar chart: blend the ROI with a black image
    # at 60% opacity to create a dark, semi-transparent backdrop.
    overlay = frame[y1:y2, x1:x2].copy()
    bg = np.zeros_like(overlay)
    frame[y1:y2, x1:x2] = cv2.addWeighted(overlay, 0.4, bg, 0.6, 0)

    # --- Inner padding ---
    # The plot area is inset from the overlay edges. pad_t (top padding)
    # is intentionally much larger than the other sides because it must
    # accommodate the legend row and the large "Overall Risk: LEVEL" label
    # that sit above the actual graph area.
    pad_l = int(12 * w / 3838)
    pad_r = int(12 * w / 3838)
    pad_t = int(70 * h / 2058)  # room for legend + large risk label
    pad_b = int(18 * h / 2058)

    plot_x1 = x1 + pad_l
    plot_x2 = x2 - pad_r
    plot_y1 = y1 + pad_t
    plot_y2 = y2 - pad_b
    inner_w = plot_x2 - plot_x1
    inner_h = plot_y2 - plot_y1

    if inner_w < 10 or inner_h < 10:
        return

    # Y-axis range: auto-scales to 120% of the peak observed value,
    # with a floor of 4.0 so the plot isn't overly zoomed in at low risk.
    all_vals = []
    for key in ("direct", "indirect", "ema"):
        vals = risk_history.get(key, [])
        if len(vals) > 0:
            all_vals.extend(vals)
    y_max = max(4.0, max(all_vals) * 1.2) if all_vals else 4.0
    y_min = 0.0

    max_points = 300
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 1.1 * w / 3838
    font_thickness = max(1, int(2.5 * w / 3838))
    small_scale = 0.95 * w / 3838

    def val_to_y(v):
        """Map a risk value to pixel Y coordinate (higher value = higher on screen).

        Screen Y increases downward, but we want higher risk values to
        appear higher on the plot. So we invert: subtract the normalized
        ratio from plot_y2 (the bottom edge of the graph). A risk of 0
        maps to plot_y2 (bottom); y_max maps to plot_y1 (top).
        """
        ratio = (v - y_min) / (y_max - y_min) if y_max > y_min else 0
        return int(plot_y2 - ratio * inner_h)

    def draw_trace(values, color, thickness):
        """Draw a polyline trace for a deque of values.

        Each value in the deque is mapped to an (x, y) point:
          - X: evenly spaced across inner_w, so index 0 is leftmost
            and the last index is rightmost (most recent data point).
          - Y: mapped via val_to_y (inverted screen coordinates).
        The points are then connected with an anti-aliased polyline.
        """
        n = len(values)
        if n < 2:
            return
        pts = []
        for i, v in enumerate(values):
            # Map index so rightmost = most recent
            x = plot_x1 + int(inner_w * i / (max_points - 1)) if max_points > 1 else plot_x1
            y = val_to_y(v)
            pts.append([x, y])
        pts_arr = np.array(pts, dtype=np.int32).reshape((-1, 1, 2))
        cv2.polylines(frame, [pts_arr], False, color, thickness, cv2.LINE_AA)

    # --- Threshold lines ---
    # Dashed horizontal lines mark the boundaries between risk levels:
    #   - 1.0: boundary between LOW and MEDIUM risk (orange)
    #   - 2.5: boundary between MEDIUM and HIGH risk (red)
    # These give the viewer fixed reference points to judge the traces against.
    thresholds = [
        (1.0, "Medium", (0, 165, 255)),
        (2.5, "High", (0, 0, 255)),
    ]
    for val, label, color in thresholds:
        if val <= y_max:
            ty = val_to_y(val)
            draw_dashed_line(frame, (plot_x1, ty), (plot_x2, ty), color,
                             thickness=max(1, int(2 * w / 3838)),
                             dash_length=int(15 * w / 3838),
                             gap_length=int(10 * w / 3838))
            cv2.putText(frame, label,
                        (plot_x2 - int(90 * w / 3838), ty - int(5 * h / 2058)),
                        font, small_scale, color, font_thickness, cv2.LINE_AA)

    # --- Three trace lines ---
    # Each trace is a rolling time series rendered as a polyline:
    #   1. "direct" (sky blue, BGR 255,180,50): collision risk — measures
    #      immediate danger from nearby objects on a collision course.
    #   2. "indirect" (purple-pink, BGR 200,100,220): driving complexity —
    #      captures environmental load (many objects, complex scene).
    #   3. "ema" (color matches current risk level): overall risk — an
    #      exponential moving average that smooths direct+indirect into
    #      a single indicator. Its color dynamically reflects the current
    #      risk level (green/orange/red) for at-a-glance readability.
    line_specs = [
        ("direct", (255, 180, 50), 3, "Collision Risk"),       # sky blue
        ("indirect", (200, 100, 220), 3, "Driving Complexity"), # purple-pink
        ("ema", risk_colors.get(risk_level, (0, 200, 0)), 4, "Overall Risk"),
    ]

    for key, color, thickness, _ in line_specs:
        vals = risk_history.get(key, [])
        if len(vals) > 0:
            scaled_t = max(1, int(thickness * w / 3838))
            draw_trace(vals, color, scaled_t)

    # --- Legend layout ---
    # Drawn in the top-left of the plot overlay. Items flow horizontally:
    # for each trace, we draw a short colored line sample followed by the
    # trace name, then advance cursor_x to the next item. This keeps the
    # legend compact and in a single row.
    legend_x = x1 + pad_l + int(6 * w / 3838)
    legend_y = y1 + int(14 * h / 2058)
    line_len = int(22 * w / 3838)
    legend_gap = int(10 * w / 3838)

    cursor_x = legend_x
    for key, color, thickness, name in line_specs:
        t = max(1, int(thickness * w / 3838))
        ly = legend_y + int(6 * h / 2058)
        cv2.line(frame, (cursor_x, ly), (cursor_x + line_len, ly), color, t, cv2.LINE_AA)
        cursor_x += line_len + int(5 * w / 3838)
        cv2.putText(frame, name, (cursor_x, legend_y + int(11 * h / 2058)),
                    font, small_scale * 0.9, color, font_thickness, cv2.LINE_AA)
        text_size = cv2.getTextSize(name, font, small_scale * 0.9, font_thickness)[0]
        cursor_x += text_size[0] + legend_gap

    # --- Risk level label ---
    # Positioned in the top-right of the plot area, this large text displays
    # the current overall risk level (e.g. "Overall Risk: HIGH"). Its color
    # is pulled from risk_colors so it matches the EMA trace and the
    # risk level — green for LOW, orange for MEDIUM, red for HIGH.
    level_color = risk_colors.get(risk_level, (200, 200, 200))
    level_scale = 1.6 * w / 3838
    level_thickness = max(2, int(4 * w / 3838))
    level_text = f"Overall Risk: {risk_level}"
    text_size = cv2.getTextSize(level_text, font, level_scale, level_thickness)[0]
    level_x = x2 - pad_r - text_size[0] - int(10 * w / 3838)
    level_y = y1 + pad_t - int(10 * h / 2058)
    cv2.putText(frame, level_text, (level_x, level_y),
                font, level_scale, level_color, level_thickness, cv2.LINE_AA)
