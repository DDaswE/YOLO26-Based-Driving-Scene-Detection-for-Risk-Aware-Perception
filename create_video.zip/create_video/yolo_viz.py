#!/usr/bin/env python3
"""
YOLO-based driving risk visualisation pipeline.

This is the main entry point for the driving-risk visualization system. It runs
a custom-trained YOLO object-detection model on dashcam footage, computes a
continuous risk score for each frame, and produces two output videos:
  1. An annotated video (original frames with bounding boxes, risk overlays,
     bar charts, and rolling plots).
  2. A mesh video (FSD-style top-down wireframe view of detected objects).

Usage:  python yolo_viz.py <video_or_dir> [--output-dir ./outputs] [--model best.pt]
"""

import argparse
import glob
import math
import os
from collections import defaultdict, deque

import cv2
import numpy as np
import torch
from ultralytics import YOLO

from overlays import draw_bar_chart, draw_rolling_plot
from mesh_video import draw_mesh_frame

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Mapping from YOLO class indices to human-readable names.
# The custom model was trained on exactly 4 classes relevant to driving risk:
#   0 = vehicle   — cars, trucks, buses, etc.
#   1 = person    — pedestrians, cyclists
#   2 = traffic light
#   3 = traffic sign
CLASS_NAMES = {0: "vehicle", 1: "person", 2: "traffic light", 3: "traffic sign"}

# BGR colour assigned to each class for OpenCV rendering (cv2 uses BGR, not RGB).
# Chosen for high contrast against typical road-scene backgrounds.
CLASS_COLORS = {
    "vehicle": (230, 150, 30),
    "person": (255, 0, 255),
    "traffic sign": (0, 255, 255),
    "traffic light": (180, 240, 80),
}

# Traffic-light-style colour coding for the overall risk level.
#   HIGH   = red     — immediate danger, e.g. close pedestrians or many nearby vehicles
#   MEDIUM = orange  — elevated caution
#   LOW    = green   — normal driving conditions
# All values are BGR for OpenCV.
RISK_COLORS = {"HIGH": (0, 0, 255), "MEDIUM": (0, 165, 255), "LOW": (0, 200, 0)}

# --- Risk computation parameters ---

# Direct-risk weights per class.  Only vehicles (0) and persons (1) contribute
# direct risk.  Person is weighted 1.5x vs vehicle's 1.0x because pedestrians
# are far more vulnerable in a collision — a higher weight reflects greater
# consequence severity, not just probability.
DIRECT_WEIGHTS = {0: 1.0, 1: 1.5}  # vehicle, person

# LAMBDA_EDGE: minimum positional risk factor for objects at the image edge.
# Objects at the horizontal center of the frame (directly ahead of the ego
# vehicle) receive pos_factor = 1.0; objects at the far left/right edge receive
# pos_factor = LAMBDA_EDGE = 0.4.  This reflects that centre-frame objects are
# more likely to be in the ego vehicle's path.
LAMBDA_EDGE = 0.4

# ALPHA_LIGHT: linear weight for each detected traffic light in the indirect
# risk term.  More visible traffic lights can signal complex intersections.
ALPHA_LIGHT = 0.5

# BETA_SIGN: coefficient for the logarithmic traffic-sign contribution.
# log1p is used (instead of a linear term) so that the first few signs add
# noticeable risk but additional signs have diminishing returns — a street
# with 20 signs is not 20x riskier than one with 1 sign.
BETA_SIGN = 0.3

# ---------------------------------------------------------------------------
# Device detection
# ---------------------------------------------------------------------------


def parse_duration(duration_str):
    """Parse duration string like '10s', '20s', '1.5m' into seconds. Returns None if input is None."""
    if duration_str is None:
        return None
    s = duration_str.strip().lower()
    if s.endswith('s'):
        return float(s[:-1])
    elif s.endswith('m'):
        return float(s[:-1]) * 60
    else:
        return float(s)  # assume seconds if no suffix


def get_device():
    # Device selection priority:
    #   1. CUDA GPU (returns integer device index 0) — fastest, NVIDIA GPUs
    #   2. Apple MPS (Metal Performance Shaders) — GPU acceleration on Apple Silicon
    #   3. CPU — universal fallback, slowest
    if torch.cuda.is_available():
        return 0  # CUDA device index
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


# ---------------------------------------------------------------------------
# Risk computation
# ---------------------------------------------------------------------------


def compute_frame_risk(results, img_width, img_height):
    """Compute per-frame driving risk from YOLO detection results.

    The risk model has two additive components:

    1. **direct_risk** — contributed only by vehicles (cls 0) and persons (cls 1):
           direct_risk = SUM( weight_i * size_factor_i * pos_factor_i )
       where:
         - weight_i   : class-dependent severity (see DIRECT_WEIGHTS)
         - size_factor : sqrt(box_area / img_area).  Larger bounding boxes mean
                         the object is physically closer to the camera, hence
                         riskier.  The square root compresses the range so that
                         a box twice the area does not produce twice the risk.
         - pos_factor  : linear interpolation from center_x_norm (0..1), mapping
                         frame centre to 1.0 and frame edges to LAMBDA_EDGE (0.4).
                         Objects directly ahead of the ego vehicle are riskier.

    2. **indirect_risk** — contributed by traffic infrastructure:
           indirect_risk = ALPHA_LIGHT * num_lights + BETA_SIGN * log1p(num_signs)
       Traffic lights add a linear term (more lights = more complex intersection).
       Traffic signs use log1p to dampen the contribution when many signs are
       present (diminishing returns).

    Returns a dict with total_risk = direct + indirect, per-class counts, and a
    per-object metadata list (object_risks) used downstream for rendering.
    """
    img_area = img_width * img_height

    direct_risk = 0.0
    num_vehicle = 0
    num_person = 0
    num_sign = 0
    num_light = 0
    # Per-object metadata carried through the pipeline so that rendering
    # functions (bounding boxes, risk flash) can access class, confidence,
    # box coordinates, and the individual partial_risk contribution.
    object_risks = []

    if results.boxes is None or len(results.boxes) == 0:
        return {
            "direct_risk": 0.0,
            "indirect_risk": 0.0,
            "total_risk": 0.0,
            "counts": {"vehicle": 0, "person": 0, "traffic light": 0, "traffic sign": 0},
            "object_risks": [],
        }

    for box in results.boxes:
        cls_id = int(box.cls.item())
        conf = float(box.conf.item())
        x1, y1, x2, y2 = map(float, box.xyxy[0].tolist())

        box_w = max(x2 - x1, 0.0)
        box_h = max(y2 - y1, 0.0)
        box_area = box_w * box_h

        center_x = (x1 + x2) / 2.0
        # Normalise centre x to [0, 1] so that positional risk is resolution-independent.
        center_x_norm = center_x / img_width if img_width > 0 else 0.5

        # pos_factor linearly interpolates between LAMBDA_EDGE (at frame edges)
        # and 1.0 (at frame centre).  |center_x_norm - 0.5| measures horizontal
        # distance from centre; multiplying by 2 maps that to [0, 1].
        pos_factor = LAMBDA_EDGE + (1 - LAMBDA_EDGE) * (1 - 2 * abs(center_x_norm - 0.5))
        pos_factor = max(LAMBDA_EDGE, min(1.0, pos_factor))

        # size_factor: sqrt(box_area / img_area).  Proportional to apparent size.
        # Larger detected objects are physically closer and therefore riskier.
        size_factor = math.sqrt(box_area / img_area) if img_area > 0 else 0.0
        partial_risk = 0.0

        if cls_id == 0:
            num_vehicle += 1
            partial_risk = DIRECT_WEIGHTS[cls_id] * size_factor * pos_factor
            direct_risk += partial_risk
        elif cls_id == 1:
            num_person += 1
            partial_risk = DIRECT_WEIGHTS[cls_id] * size_factor * pos_factor
            direct_risk += partial_risk
        elif cls_id == 2:
            num_light += 1
        elif cls_id == 3:
            num_sign += 1

        object_risks.append({
            "class_id": cls_id,
            "class_name": CLASS_NAMES.get(cls_id, str(cls_id)),
            "confidence": conf,
            "box": [x1, y1, x2, y2],
            "partial_risk": partial_risk,
        })

    # Indirect risk: linear from traffic lights, logarithmic from signs.
    # log1p(n) = log(1 + n) so a single sign still contributes, but 10 signs
    # contribute only ~2.4x what 1 sign does — preventing sign-heavy streets
    # from dominating the risk score.
    indirect_risk = ALPHA_LIGHT * num_light + BETA_SIGN * math.log1p(num_sign)
    total_risk = direct_risk + indirect_risk

    return {
        "direct_risk": float(direct_risk),
        "indirect_risk": float(indirect_risk),
        "total_risk": float(total_risk),
        "counts": {
            "vehicle": num_vehicle,
            "person": num_person,
            "traffic light": num_light,
            "traffic sign": num_sign,
        },
        "object_risks": object_risks,
    }


def update_ema_risk(current_risk, previous_ema=None, momentum=0.8):
    """Exponential moving average (EMA) for temporal smoothing.

    Formula:  ema_t = momentum * ema_{t-1} + (1 - momentum) * current_risk

    With momentum = 0.8, 80% of the smoothed value comes from the previous
    EMA and only 20% from the new observation.  This provides temporal
    stability — the displayed risk level won't flicker wildly between frames
    when detections appear and disappear due to occlusion or model noise.
    The effective half-life is ~3 frames (ln(2)/ln(1/0.8) ≈ 3.1).
    """
    if previous_ema is None:
        return current_risk
    return momentum * previous_ema + (1 - momentum) * current_risk


def risk_level(score, low_th=1.0, high_th=2.5):
    """Map a continuous risk score to a discrete qualitative level.

    Two-threshold bucketing:
      score < 1.0  -> LOW    (normal driving, minimal hazards)
      score < 2.5  -> MEDIUM (elevated caution, e.g. nearby vehicles)
      score >= 2.5 -> HIGH   (immediate danger, e.g. close pedestrians)
    """
    if score < low_th:
        return "LOW"
    elif score < high_th:
        return "MEDIUM"
    return "HIGH"


# ---------------------------------------------------------------------------
# Bounding box drawing
# ---------------------------------------------------------------------------


def draw_bounding_boxes(frame, risk_info, results):
    """Draw coloured bounding boxes with labels on *frame* (mutates in-place).

    Label format varies by class:
      - Vehicles and persons (cls 0, 1): show confidence AND individual risk
        score (e.g. "vehicle 94% R=0.37") so the viewer can see which objects
        drive the overall risk.
      - Traffic lights and signs (cls 2, 3): show confidence only (e.g.
        "traffic light 87%") since they do not carry individual partial_risk.
    """
    if results.boxes is None or len(results.boxes) == 0:
        return

    for obj, box in zip(risk_info["object_risks"], results.boxes):
        cls_id = obj["class_id"]
        conf = obj["confidence"]
        name = obj["class_name"]
        color = CLASS_COLORS.get(name, (200, 200, 200))

        x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

        # Build label — include risk score only for direct-risk classes
        if cls_id in (0, 1):
            label = f"{name} {conf:.0%} R={obj['partial_risk']:.2f}"
        else:
            label = f"{name} {conf:.0%}"

        # Draw a filled rectangle behind the text for readability
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
        y_top = max(y1 - th - 6, 0)
        cv2.rectangle(frame, (x1, y_top), (x1 + tw, y1), color, -1)
        cv2.putText(
            frame, label, (x1, max(y1 - 4, 15)),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA,
        )


# ---------------------------------------------------------------------------
# Risk flash effect
# ---------------------------------------------------------------------------


def draw_risk_flash(frame, risk_info, level, frame_idx):
    """Pulsing border around top-risk objects when risk is MEDIUM or HIGH.

    How it works:
      - LOW risk: no flash at all — avoids visual noise during normal driving.
      - MEDIUM / HIGH: the top 3 objects (by partial_risk) receive a thick
        coloured border that pulses using a sinusoidal brightness envelope.
      - Pulse formula: alpha = 0.5 * (1 + sin(2*pi*frame_idx / 15))
        This gives a smooth oscillation with a period of 15 frames (~0.5 s
        at 30 fps).  alpha ranges from 0 (invisible) to 1 (full colour),
        and the risk-level colour (red or orange) is multiplied by alpha
        to create the pulsing effect.
      - Objects with partial_risk == 0 (e.g. lights/signs) are skipped even
        if they appear in the top-3 sort.
    """
    if level == "LOW":
        return

    # Find top 3 objects by partial_risk
    sorted_objs = sorted(risk_info["object_risks"], key=lambda o: o["partial_risk"], reverse=True)
    top_objs = sorted_objs[:3]

    # Sinusoidal pulse: period = 15 frames, range [0, 1]
    pulse_alpha = 0.5 * (1 + math.sin(2 * math.pi * frame_idx / 15))
    risk_color = RISK_COLORS.get(level, (0, 0, 255))

    # Modulate the risk colour intensity by the pulse value
    modulated = tuple(int(c * pulse_alpha) for c in risk_color)

    for obj in top_objs:
        if obj["partial_risk"] <= 0:
            continue
        x1, y1, x2, y2 = map(int, obj["box"])
        cv2.rectangle(frame, (x1, y1), (x2, y2), modulated, 7)


# ---------------------------------------------------------------------------
# Main processing loop
# ---------------------------------------------------------------------------


def process_video(video_path, output_dir, model, args):
    """Process a single video file: run detection, draw overlays, write outputs.

    Produces two output videos (dual-output pipeline):
      1. *_annotated.mp4 — original frames with bounding boxes, risk flash
         effects, a bar chart of class counts, and a rolling risk plot.
      2. *_mesh.mp4 — FSD-style top-down wireframe view generated by
         mesh_video.draw_mesh_frame (skipped if --no-mesh is set).

    State tracked across frames:
      - ema_risk: exponentially smoothed risk score (temporal stability).
      - risk_history: three deques (direct, indirect, ema) with maxlen=300.
        At 30 fps this stores ~10 seconds of history for the rolling plot.
      - prev_tracks: previous-frame object positions used by the mesh renderer
        to draw motion trails.

    Per-frame pipeline:
      YOLO inference -> compute_frame_risk -> EMA update -> append to history
      -> draw annotated frame (boxes + flash + overlays) -> draw mesh frame
    """
    device = get_device()
    print(f"Processing: {video_path}")
    print(f"Device: {device}")

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"ERROR: cannot open {video_path}")
        return

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    print(f"Video: {width}x{height}, FPS={fps:.2f}, Total frames={total_frames}")

    duration_sec = parse_duration(args.duration)
    if duration_sec is not None:
        max_frames = min(int(duration_sec * fps), total_frames)
    else:
        max_frames = total_frames
    print(f"Processing {max_frames} frames ({max_frames/fps:.1f}s)")

    stem = os.path.splitext(os.path.basename(video_path))[0]
    os.makedirs(output_dir, exist_ok=True)

    # Set up annotated video writer
    ann_path = os.path.join(output_dir, f"{stem}_annotated.mp4")
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer_annotated = cv2.VideoWriter(ann_path, fourcc, fps, (width, height))

    # Set up mesh video writer (optional — skipped with --no-mesh)
    writer_mesh = None
    if not args.no_mesh:
        mesh_path = os.path.join(output_dir, f"{stem}_mesh.mp4")
        writer_mesh = cv2.VideoWriter(mesh_path, fourcc, fps, (width, height))

    # --- Per-video state ---
    ema_risk = None  # EMA-smoothed risk; None triggers initialisation on first frame
    risk_history = {  # Rolling history for the on-screen plot (maxlen=300 ~ 10s at 30fps)
        "direct": deque(maxlen=300),
        "indirect": deque(maxlen=300),
        "ema": deque(maxlen=300),
    }
    prev_tracks = {}  # Previous-frame object positions for mesh motion trails
    frame_idx = 0

    # --- Frame-by-frame processing loop ---
    while frame_idx < max_frames:
        ret, frame = cap.read()
        if not ret:
            break

        # Step 1: Run YOLO inference on the raw frame
        results = model(frame, verbose=False, device=device, imgsz=args.imgsz, conf=args.conf)[0]
        # Step 2: Compute per-frame risk from detection results
        risk_info = compute_frame_risk(results, width, height)
        # Step 3: Smooth the raw risk with EMA to avoid frame-to-frame flicker
        ema_risk = update_ema_risk(risk_info["total_risk"], ema_risk)
        # Step 4: Discretise smoothed risk into LOW / MEDIUM / HIGH
        level = risk_level(ema_risk)

        # Append to rolling history (used by the on-screen plot)
        risk_history["direct"].append(risk_info["direct_risk"])
        risk_history["indirect"].append(risk_info["indirect_risk"])
        risk_history["ema"].append(ema_risk)

        # Aggregate per-class counts for the bar chart overlay
        counts = defaultdict(int)
        for obj in risk_info["object_risks"]:
            counts[obj["class_name"]] += 1

        # --- Annotated frame ---
        annotated = frame.copy()
        draw_bounding_boxes(annotated, risk_info, results)
        draw_risk_flash(annotated, risk_info, level, frame_idx)
        bar_bottom = draw_bar_chart(annotated, counts, CLASS_COLORS)
        draw_rolling_plot(annotated, risk_history, level, RISK_COLORS, bar_chart_bottom=bar_bottom)
        writer_annotated.write(annotated)

        # --- Mesh frame (FSD-style top-down view) ---
        if writer_mesh is not None:
            mesh_frame, prev_tracks = draw_mesh_frame(
                (height, width, 3),
                risk_info["object_risks"],
                level,
                risk_history,
                prev_tracks,
                CLASS_COLORS,
                RISK_COLORS,
            )
            writer_mesh.write(mesh_frame)

        # Log progress every 100 frames so long-running jobs show signs of life
        if frame_idx % 100 == 0:
            print(f"Frame {frame_idx}/{total_frames} | EMA Risk: {ema_risk:.3f} | Level: {level}")

        frame_idx += 1

    cap.release()
    writer_annotated.release()
    if writer_mesh is not None:
        writer_mesh.release()

    print(f"Done. Processed {frame_idx} frames.")
    print(f"  Annotated -> {ann_path}")
    if not args.no_mesh:
        print(f"  Mesh      -> {mesh_path}")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def main():
    parser = argparse.ArgumentParser(description="YOLO driving-risk visualisation")
    parser.add_argument("input_path", help="Video file or directory of videos")
    parser.add_argument("--output-dir", "-o", default="./outputs", help="Output directory (default: ./outputs)")
    parser.add_argument("--model", default="/Users/xuzichun/Desktop/project/newdata_yolo26_960run_100_32/weights/best.pt", help="YOLO model weights (default: best.pt)")
    # imgsz=960: balances detection accuracy (higher res catches small objects)
    # against inference speed.  Common YOLO sizes are 640, 960, 1280.
    parser.add_argument("--imgsz", type=int, default=960, help="Inference image size (default: 960)")
    # conf=0.25: permissive confidence threshold — lets through more detections
    # to avoid missing hazards.  False positives are less costly than missed
    # pedestrians in a safety-oriented pipeline.
    parser.add_argument("--conf", type=float, default=0.25, help="Confidence threshold (default: 0.25)")
    parser.add_argument("--no-mesh", action="store_true", help="Skip mesh video generation")
    parser.add_argument("--duration", type=str, default=None,
                        help="Duration to process, e.g. '10s', '20s', '1.5m'. Default: full video")
    args = parser.parse_args()

    model = YOLO(args.model)

    # Auto-detect whether input_path is a single video file or a directory.
    # If it's a directory, discover all .mov and .mp4 files inside it.
    # These two formats cover the vast majority of dashcam recordings.
    if os.path.isfile(args.input_path):
        videos = [args.input_path]
    elif os.path.isdir(args.input_path):
        videos = sorted(
            glob.glob(os.path.join(args.input_path, "*.mov"))
            + glob.glob(os.path.join(args.input_path, "*.mp4"))
        )
        if not videos:
            print(f"No .mov or .mp4 files found in {args.input_path}")
            return
    else:
        print(f"ERROR: {args.input_path} is not a valid file or directory")
        return

    print(f"Found {len(videos)} video(s) to process")
    for video_path in videos:
        process_video(video_path, args.output_dir, model, args)


if __name__ == "__main__":
    main()
